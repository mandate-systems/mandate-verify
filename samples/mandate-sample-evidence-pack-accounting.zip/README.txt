Mandate governance evidence pack
================================

Tenant:       b51f8872-66b5-4db5-a310-d5afab3318f6
Window:       2026-07-20T22:23:54.0000000+00:00 .. 2026-07-20T22:27:04.0000000+00:00
Generated at: 2026-07-20T22:26:11.1675256+00:00
Signing key:  SHA-256 9a914bf1310855175c7d868ad434987075412f627b2e8c18e5634e0bfcba045f

SCOPE: In-path evidence only. This pack covers the decisions and policy changes that
passed through Mandate for the selected window. It is NOT an inventory of all AI use in
your organization. The gaps this tenant has declared are listed in scope/blind-spots.json:
every blind spot recorded as open as of the generation time above, with its owner,
compensating control, and review cadence. Blind spots are current state, not windowed.
summary/decision-mix.json breaks the window's decisions down by connector and retention
class, so the pack states how much of its evidence is content-inspected and how much is
metadata-only. register/purposes.json lists the purpose registry (slug and display label,
including retired entries) as of the same generation time; register/decisions.json refers
to purposes by slug.

Re-verify offline: each file's SHA-256 is listed in manifest.json, and the manifest carries
an Ed25519 signature over that hash list (plus the pack identity, the export window, and the
truncated / checkpointsTruncated completeness flags). Recompute the hashes and verify the signature with
the embedded public key — confirm its SHA-256 fingerprint matches the one above and the one
on the checkpoints you already trust — no network access required. Checkpoints under
checkpoints/ verify independently against the same audit chain.
