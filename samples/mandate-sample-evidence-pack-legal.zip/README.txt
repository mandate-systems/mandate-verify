Mandate governance evidence pack
================================

Tenant:       f5df00fc-fdfb-4479-8695-7668230bcddf
Window:       2026-08-11T21:21:30.0000000+00:00 .. 2026-08-11T21:24:49.0000000+00:00
Generated at: 2026-08-11T21:23:52.1281477+00:00
Signing key:  SHA-256 9a914bf1310855175c7d868ad434987075412f627b2e8c18e5634e0bfcba045f

SCOPE: In-path evidence only. This pack covers the decisions and policy changes that
passed through Mandate for the selected window. It is NOT an inventory of all AI use in
your organization. The gaps this tenant has declared are listed in scope/blind-spots.json:
every blind spot recorded as open as of the generation time above, with its owner,
compensating control, and review cadence. Blind spots are current state, not windowed.
summary/decision-mix.json breaks the window's decisions down by connector and retention
class, so the pack states how much of its evidence is content-inspected and how much is
metadata-only. register/purposes.json lists the purpose registry (slug and display label,
including retired entries) as of the same generation time; register/decisions.json refers
to purposes by slug.

RULE BASIS: summary/decision-mix.json also separates the window's decisions by rule basis:
binding, voluntary, or unlabeled. Basis is the tenant's own label on its own rule, derived
from the policy version in force when each decision was made; rules carrying no label count
as unlabeled, and the absence of a label is never treated as either claim. A decision that
fired rules of both kinds counts under both buckets, so basis counts can exceed the
per-decision totals. An outcome under a voluntary rule is a house-standard outcome and is
never presentable as a breach of a binding obligation.

MANDATES: register/mandates.json lists the tenant's mandate registry as of the same
generation time: each recorded authority grant with its owner, effective window, declared
scope, and lifecycle state, including revoked and expired grants. A decision row's
mandateSlug names the mandate the presented credential was bound to at write time,
whatever the decision was. On an allowed decision, the reference supports 'executed
under this grant'. A decision denied FOR its mandate says so explicitly: it is a blocked
decision whose rule hits carry the policy.mandate_not_valid marker (or, on a resumed hold,
policy.resume_mandate_not_valid); a blocked decision without that marker was blocked by
policy, and the reference only records which grant the credential operated under. It
does not show the grant was wise, and a grant's declared scope never evaluated traffic.
Rows without the field were recorded by a credential bound to no mandate.

POLICY TRAIL: mutations/policy-trail.json lists every recorded administrative action in the
window: policy changes alongside the other configuration changes and access-view records the
operator log holds. A policy activation or deactivation row carries a transition record
stating why the prior rule set went away (superseded, repealed, or an emergency change), the
operator's typed reason, and the version in force before the change. The record is written
to an append-only operator log at the moment of the change and is not editable afterward.
Rows recorded before transition records shipped carry no transition field.

ASSURANCE: assurance/detector-catch-rate.json states how the shipped detector library
measured against Mandate's own synthetic, annotated test corpus at the accepted baseline
run named inside the file. It describes the software build, not this tenant: the same file
ships in every pack and contains no tenant data. It is not a measurement of your authored
policy, of live traffic, or of model behaviour. Detection is signal-grade, never the control,
and a recorded catch rate does not verify behaviour in production. A detector shipped
before its first accepted baseline run is listed with an explicit not-yet-baselined status
rather than a number.

Re-verify offline: each file's SHA-256 is listed in manifest.json, and the manifest carries
an Ed25519 signature over that hash list (plus the pack identity, the export window, and the
truncated / checkpointsTruncated completeness flags). Recompute the hashes and verify the signature with
the embedded public key. Confirm its SHA-256 fingerprint matches the one above and the one on
the checkpoints you already trust. No network access is required. Checkpoints under
checkpoints/ verify independently against the same audit chain.
