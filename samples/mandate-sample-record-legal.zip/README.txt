Mandate signed record
=====================

Harbour Square Legal LLP, 20 Nov 2026, 09:55 to 10:35 America/Toronto.
Made and signed 20 Nov 2026, 10:38 America/Toronto.

report/report.pdf is the printed report for this window. register/decisions.json lists every decision
and the rules that applied to it.

To check that nothing changed since signing, drop this .zip on mandateco.ca/verify.html or run
mandate-verify.mjs from that page, and compare the signing key's fingerprint:
9a914bf1310855175c7d868ad434987075412f627b2e8c18e5634e0bfcba045f

Outside timestamps: each of the 42 signed checkpoints carries a timestamp from an independent time-stamp authority (RFC 3161), which shows the checkpoint existed by that time. The verifier checks each one offline.

The sections below are for auditors and for anyone checking the files by hand.

PACK DETAILS: made for Harbour Square Legal LLP (Mandate ID c10dad5f-ec95-490e-b4b7-c624135c5512).
The window in UTC, as manifest.json carries it: 2026-11-20T14:55:30.0000000+00:00 to 2026-11-20T15:35:48.0000000+00:00.
Made and signed at 2026-11-20T15:38:49.5161043+00:00.

SCOPE: In-path evidence only. This pack covers the decisions and policy changes that
passed through Mandate for the selected window. It is NOT an inventory of all AI use in
your organization. The declared gaps are listed in scope/blind-spots.json:
every blind spot recorded as open as of the generation time above, with the owner,
compensating control and review cadence given to it, if any (only the description is
required). Blind spots are current state, not windowed.
summary/decision-mix.json breaks the window's decisions down by connector and retention
class, so the pack states how much of its evidence is content-inspected and how much is
metadata-only, and its responses block counts the chat answers of requests not held for approval: digested,
retained, inspected, rewritten or withheld. register/purposes.json lists the purpose registry (slug and display label,
including retired entries) as of the same generation time; register/decisions.json refers
to purposes by slug.

REPORT: report/report.pdf is a printable summary of this window for readers who will not open
the JSON: what happened to the requests, the rules that fired most, the requests held for
approval, what the organization's other AI tools reported in their own logs, the state of the
record, and how to check the pack. report/summary.json carries the same figures, each naming
the file it is re-derived from.

RULE BASIS: summary/decision-mix.json also separates the window's decisions by rule basis:
binding, voluntary, or unlabeled. Basis is your own label on your own rule, derived
from the policy version in force when each decision was made; rules carrying no label count
as unlabeled, and the absence of a label is never treated as either claim. A decision that
fired rules of both kinds counts under both buckets, so basis counts can exceed the
per-decision totals. An outcome under a voluntary rule is a house-standard outcome and is
never presentable as a breach of a binding obligation.

FRAMEWORKS: summary/framework-coverage.json lists, for each policy, the framework
references your authors recorded on its active rules (for example an EU AI Act
article or an OWASP item), and separates the window's decisions by those references. The
mapping reflects the active policy as of the generation time above; the decision breakdown
follows the policy version in force when each decision was made. A reference is your
own annotation on your own rule: Mandate records it and verifies nothing about it,
and nothing in the file is a statement that any framework obligation is satisfied.
Decisions under rules carrying no reference count as unmapped, and the absence of a
reference is never treated as a gap.

ATTACHMENTS: summary/attachments.json counts the window's decisions by the kind of attachment
the request carried (image, audio, file, or unknown for a part the inventory could not recognise),
as recorded on each decision by the attachment inventory, and counts the attached documents
whose text was read and those that could not be.
It names the earliest inventoried decision held and whether the inventory covered
the whole window, part of it, or none of it; decisions made before the inventory existed are
never counted as attachment-free. Images and audio are recorded, never inspected.

MANDATES: register/mandates.json lists the mandate registry as of the same
generation time: each mandate with who approved it, the tools it approves (who approved
each and when), its purposes, its dates and its state, including ended and expired
mandates. Each approval, first list of a tool server, extension, renewal, takeover and
end is in the change trail with what it approved, sealed into the chain. A decision row's
mandateSlug names the mandate the presented credential was bound to at write time,
whatever the decision was. On an allowed decision, the reference supports 'executed
under this grant'. A decision denied FOR its mandate says so explicitly: it is a blocked
decision whose rule hits carry the policy.mandate_not_valid marker (or, on a resumed hold,
policy.resume_mandate_not_valid); a blocked decision without that marker was blocked by
policy, and the reference only records which grant the credential operated under. It
does not show the grant was wise. A call outside the mandate (a tool it does not approve,
or a purpose it does not list) carries a policy.mandate_scope_drift marker, _held when it
was held for approval, _blocked when it was refused.
Rows without the field were recorded by a credential bound to no mandate.
AGENT EXPOSURE: summary/agent-exposure.json answers which agents, under whose authority, doing
what, with what oversight. It counts the agents active and revoked at the end of the window; the
live credentials agents act with, bound to a valid mandate, bound to none, or bound to one that
is revoked, expired or not yet in effect, as of generation; the holds raised for agents in the
window by channel and how they ended (approved, denied, or expired with nobody deciding); the
agents registered and revoked in the window; and the decisions flagged, held or refused for
being outside an agent's mandate, with the date that check began and whether it covered the
whole window. With no agents, the file carries zeros. Counts, never judgments.

AI SYSTEMS AND ASSESSMENTS: register/ai-systems.json lists the AI system register as of the
same generation time, with what each system is linked to in Mandate. assessments/findings.json
lists the assessments concluded in the window, each with its findings and its sealed document;
assessments/oscal-assessment-results.json carries the same assessments as one OSCAL 1.1.2
assessment-results document, one result each. assessments/reviews.json lists the reviews of
findings made in the window, assessments/artifacts.json the artifact versions supplied in it,
by name and SHA-256, never their files, assessments/measure-values.json the values recorded
for measures, and assessments/impact-assessments.json the versions of impact assessments. Each
sealed document and record is the exact text Mandate hashed, so its SHA-256 recomputes to the
one its change-trail entry carries, and the free verifier checks each one offline, with the row
beside it. A result says what Mandate's record showed against a requirement; it is not a
statement that the system complies with the framework. A file that says truncated stopped at its
size limit and holds the earliest rows of the window (the register, the first systems by name);
the rest are in Mandate.
assessments/final-decisions.json lists the final decisions each system's case system recorded
in the window, batch by batch: each batch as the exact text Mandate hashed, with its sealed
change-trail entry, and each decision as its document and salt, so one decision can be checked
without disclosing the others.

PEOPLE: a row in register/decisions.json may carry a person field: the work email or user name
a person signed in to the AI web gateway with, as it was issued. It is present only on
requests sent through that gateway by a credential issued to that person, and absent
on every other row. The hash chain fixes a salted seal of that name, and the row's personSalt
lets the verifier recompute it, so a name changed after the fact no longer matches its record;
erased on request, the name and its salt go and the seal left behind reveals nothing. The
person is the holder of a credential an administrator issued and
saw once at issue, so the field attributes a request to that credential's holder, not to a
verified individual, and a shared credential attributes to its holder.
A person's row may also carry senderCanApprove: true. A hold rule matched the request and it
was not held for approval, because the holder of the credential can approve held requests
themselves (an active console account at the same address, with the approver or administrator
role). The other rules still applied, so the request may have been
masked or refused; the row's action says which. The record's rule hits carry the hold rule and
the policy.sender_can_approve marker.

IMPORTED ACTIVITY: imports/<feed>.json, when present, lists what an AI vendor reported through its own
audit feed (for example Microsoft 365 Copilot). Mandate did not see or decide these requests; each row
carries the SHA-256 of the vendor's record as received, and the file states how much of the window
the feed covered. register/decisions.json and the decision counts never include these rows.
Each row's ruleHits lists only the rules that fired on it; Mandate's notes on reading it, such as a
part it could not read, are in notes.

CHANGE TRAIL: mutations/policy-trail.json lists every recorded administrative action in the
window: policy changes alongside the other configuration changes and access-view records the
operator log holds. A policy activation or deactivation row carries a transition record
naming the version in force before the change and, when one was given, the reason the
operator typed; an older row may also state why the prior rule set went away (superseded,
repealed, or an emergency change). The record is written to an append-only operator log at
the moment of the change and is not editable afterward. It is kept as long as the records of
AI use are kept; an older entry goes after the record that sealed it, which the
records file then shows as erased by retention.
Within about a minute it is also sealed into the same hash chain as the decisions: a record
with connector change_trail whose correlationId is the entry's id carries the SHA-256 of what
the row says, who acted as they stood when it was sealed, and why. A row's actorSalt lets the
verifier recompute the seal of the actor's e-mail. What a policy version changed is sealed too.
A change to a list of names says how many entries were added and removed, never which: the
entries are the list's, sealed in the version's text (policy/lists.json lists each one, and
holds its names in a copy exported with them).
A row whose actorType is mandate_support records an action Mandate took as the operator of
the service; it carries no personal identity by design. Quote that row's
id to Mandate as the support reference and Mandate can account for the action from its own
records. A mutationReason field, where present, is the reason the operator typed.
A row whose actorType is system is a change Mandate made by itself, such as an alert sent, a
held request that ran out or a retention sweep; one whose actorType is directory was made by
your own directory through directory sync. Neither is an operator action and neither
names a person.
A row of register/decisions.json whose action is maintenance.database_session records a
maintenance session the operator of the service opened on the database itself. Such a session
can reach every record the database holds, so it appears in every customer's records, yours
included, whether or not it touched them. Its maintenance field gives when the session began
and ended. A session still open after an hour is recorded then, with no end, and again when it
ends. The field also says whether the session changed anything: made (it changed records or the
structure of the database), none (nothing was changed), or unknown (the session was not logged
statement by statement, or overlapped a gap in the database's record of access; read it as made).
A row whose action is maintenance.database_record_gap records a time when the database's record
of access may be incomplete: its logging settings were not as installed, a session changed them,
or the log could not be read in full. Nothing shows what happened then, so its maintenance field
is always unknown.
A row whose action is maintenance.host_session records a session in which the operator signed in
to the server that holds the database. It appears in every customer's records, because someone
with full rights on that server can reach every customer's data. Its maintenance field reads the
same way: made (it changed the server's accounts, settings, installed software or logs), none (it
ran nothing with administrator rights and changed none of those), or unknown (it used
administrator rights, or overlapped a gap in the server's record of access; read it as made). A
row whose action is maintenance.host_record_gap records a time when the server's record of access
was interrupted, including every restart of the server. Nothing shows what happened then, so its
maintenance field is always unknown. A session or gap still open after an hour is written then
with no end time, and written again with its end once it closes.

ASSURANCE: assurance/detector-catch-rate.json states how the shipped detector library
measured against Mandate's own synthetic, annotated test corpus at the accepted baseline
run named inside the file. It describes the software build, not these records: the same file
ships in every pack and contains no customer data. It is not a measurement of your authored
policy, of live traffic, or of model behaviour. Detection is signal-grade, never the control,
and a recorded catch rate does not verify behaviour in production. A detector shipped
before its first accepted baseline run is listed with an explicit not-yet-baselined status
rather than a number. A detector that matches the attachments a request carried rather than
its text is named out of scope under the library, because no text corpus can measure it.

THE RECORDS: chain/links.json carries every audit record in the sealed windows this pack
covers, in chain order, as the exact bytes Mandate hashed (record, base64). A record removed
under a privacy request or by retention appears by its recorded hash only, with erasedBy naming
the entry that recorded its erasure; chain/erasures.json carries those entries, whenever they
were made, and the verifier refuses a removal no entry recorded. Each record names
the hash of the one before it; each checkpoint's signed Merkle root recomputes from the
records in its window; each decision in register/decisions.json names its record's hash
(recordSha256); and policy/versions.json carries each policy version's text with its SHA-256,
which every record it decided carries. The free verifier checks all of it offline. When the
file says truncated, it carries part of the records: it stops at its size cap, and when the
register was cut to its row cap, it starts at the sealed window of the register's oldest
decision. Checkpoints whose records it does not carry are reported as not covered.

LISTS OF NAMES: a rule's list of names, a client list for example, appears in the policy text
as a seal and a count, never as the names. The seal is the SHA-256 of the names with a random
salt, so it reveals nothing about them and a guessed name cannot be checked against it, yet any
change to the list changes it. policy/lists.json names every sealed list. When the export
includes the names, it also carries each list's names and salt, and the verifier recomputes
every seal from them and finds it in its policy version's text.
This export leaves the names out. Your administrator can export the same period with them.

Re-verify offline: each file's SHA-256 is listed in manifest.json, and the manifest carries
an Ed25519 signature over that hash list (plus the pack identity, the export window, and the
truncated / checkpointsTruncated / mutationsTruncated completeness flags). Recompute the hashes
and verify the signature with the embedded public key. Confirm its SHA-256 fingerprint matches
the one above and the one on the checkpoints you already trust. No network access is required.
Checkpoints under checkpoints/ verify independently against the same audit chain.
